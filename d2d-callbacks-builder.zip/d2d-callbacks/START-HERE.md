# D2D Callback Board — start here

You'll end up with ONE file, index.html, that is the whole website.

## A. Firebase (free database) — skip if you already did this
1. console.firebase.google.com → **Create a project** (Analytics off).
2. **Build → Firestore Database → Create database** → production mode → Create.
3. **Rules** tab → replace everything with the contents of `firestore.rules` → **Publish**.
4. **Gear icon → Project settings → Your apps → web icon `</>`** → register the app. Keep the page with `const firebaseConfig = {…}` open.

## B. Build the site
1. Double-click **build-my-site.html** (open it in Chrome or Edge).
2. Paste the `firebaseConfig` block, type the team code twice, click **Download my index.html**.

## C. Put it online (Netlify)
1. On your Desktop make a folder called `callback-site` and put the downloaded **index.html** in it — only that file.
2. Log in at app.netlify.com, go to **app.netlify.com/drop**, drag the **callback-site** folder onto the page.
3. Open the link Netlify gives you.

Agents: `https://your-site.netlify.app`
Wall display: `https://your-site.netlify.app/?view=display`

## If Netlify still won't take it — GitHub Pages instead (free)
1. Sign in at github.com → **New repository** → name `d2d-callbacks` → **Public** → Create.
2. Click **uploading an existing file** → drag in **index.html** → **Commit changes**.
3. **Settings → Pages** → Source: **Deploy from a branch** → Branch: **main**, folder **/ (root)** → Save.
4. After about a minute the link appears at the top of that page: `https://yourname.github.io/d2d-callbacks/`
   (Customer data isn't in the file — it stays in Firebase behind the team code.)

## What you should see
- **Team code box** → it's working. Type the code, then your name.
- **"Finish setup"** → the file wasn't made with the builder. Redo step B.
- **"Page not found"** → index.html isn't at the top level. Upload only the file / the folder that directly holds it.
